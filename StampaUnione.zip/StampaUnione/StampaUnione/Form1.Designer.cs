﻿namespace StampaUnione
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCreaDocumento = new System.Windows.Forms.Button();
            this.btnChiudiDocumento = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtCognome = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtData = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtAssenza = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnNuovoAlunno = new System.Windows.Forms.Button();
            this.btnNuovaAssenza = new System.Windows.Forms.Button();
            this.btnStampoPDF = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnCreaDocumento
            // 
            this.btnCreaDocumento.Location = new System.Drawing.Point(41, 21);
            this.btnCreaDocumento.Name = "btnCreaDocumento";
            this.btnCreaDocumento.Size = new System.Drawing.Size(135, 23);
            this.btnCreaDocumento.TabIndex = 0;
            this.btnCreaDocumento.Text = "Crea Documento";
            this.btnCreaDocumento.UseVisualStyleBackColor = true;
            this.btnCreaDocumento.Click += new System.EventHandler(this.btnCreaDocumento_Click);
            // 
            // btnChiudiDocumento
            // 
            this.btnChiudiDocumento.Location = new System.Drawing.Point(227, 21);
            this.btnChiudiDocumento.Name = "btnChiudiDocumento";
            this.btnChiudiDocumento.Size = new System.Drawing.Size(135, 23);
            this.btnChiudiDocumento.TabIndex = 1;
            this.btnChiudiDocumento.Text = "Chiudi Documento";
            this.btnChiudiDocumento.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(38, 127);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Cognome";
            // 
            // txtCognome
            // 
            this.txtCognome.Location = new System.Drawing.Point(119, 124);
            this.txtCognome.Name = "txtCognome";
            this.txtCognome.Size = new System.Drawing.Size(100, 20);
            this.txtCognome.TabIndex = 3;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(119, 168);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 20);
            this.txtNome.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(38, 171);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Nome";
            // 
            // txtData
            // 
            this.txtData.Location = new System.Drawing.Point(119, 228);
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(100, 20);
            this.txtData.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(38, 231);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Data";
            // 
            // txtAssenza
            // 
            this.txtAssenza.Location = new System.Drawing.Point(119, 273);
            this.txtAssenza.Name = "txtAssenza";
            this.txtAssenza.Size = new System.Drawing.Size(100, 20);
            this.txtAssenza.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(38, 276);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Tipo Assenza";
            // 
            // btnNuovoAlunno
            // 
            this.btnNuovoAlunno.Location = new System.Drawing.Point(245, 147);
            this.btnNuovoAlunno.Name = "btnNuovoAlunno";
            this.btnNuovoAlunno.Size = new System.Drawing.Size(92, 37);
            this.btnNuovoAlunno.TabIndex = 10;
            this.btnNuovoAlunno.Text = "Nuovo Alunno";
            this.btnNuovoAlunno.UseVisualStyleBackColor = true;
            this.btnNuovoAlunno.Click += new System.EventHandler(this.btnNuovoAlunno_Click);
            // 
            // btnNuovaAssenza
            // 
            this.btnNuovaAssenza.Location = new System.Drawing.Point(245, 241);
            this.btnNuovaAssenza.Name = "btnNuovaAssenza";
            this.btnNuovaAssenza.Size = new System.Drawing.Size(92, 37);
            this.btnNuovaAssenza.TabIndex = 11;
            this.btnNuovaAssenza.Text = "Nuovo Assenza";
            this.btnNuovaAssenza.UseVisualStyleBackColor = true;
            // 
            // btnStampoPDF
            // 
            this.btnStampoPDF.Location = new System.Drawing.Point(439, 21);
            this.btnStampoPDF.Name = "btnStampoPDF";
            this.btnStampoPDF.Size = new System.Drawing.Size(135, 23);
            this.btnStampoPDF.TabIndex = 12;
            this.btnStampoPDF.Text = "Stampa PDF";
            this.btnStampoPDF.UseVisualStyleBackColor = true;
            this.btnStampoPDF.Click += new System.EventHandler(this.btnStampoPDF_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnStampoPDF);
            this.Controls.Add(this.btnNuovaAssenza);
            this.Controls.Add(this.btnNuovoAlunno);
            this.Controls.Add(this.txtAssenza);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtCognome);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnChiudiDocumento);
            this.Controls.Add(this.btnCreaDocumento);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCreaDocumento;
        private System.Windows.Forms.Button btnChiudiDocumento;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCognome;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtAssenza;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnNuovoAlunno;
        private System.Windows.Forms.Button btnNuovaAssenza;
        private System.Windows.Forms.Button btnStampoPDF;
    }
}

