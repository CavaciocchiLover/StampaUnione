﻿using Microsoft.Office.Interop.Word;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace StampaUnione
{
    public class clsWord
    {
        _Application myWord;
        List<Document> liste_pagine = new List<Document>();
        
        public void creaDocumento(int n_alunni, bool visible = true)
        {
            myWord = new Microsoft.Office.Interop.Word.Application();
            myWord.Visible = visible;

            for (int i = 0; i < n_alunni; i++)
            {
                liste_pagine.Add(myWord.Documents.Add());
            }
        }

        public void impostaRange(ref object start, ref object end, Document pagina)
        {
            start = pagina.Sentences[pagina.Sentences.Count].End - 1;
            end = pagina.Sentences[pagina.Sentences.Count].End;
        }

        public void inserisciTesto(string text, List<String> alunni)
        {
            Document pagina;

            for (int i = 0; i < myWord.Documents.Count; i++)
            {
                string[] dati_alunni = alunni[i].Split(';');
                string testo = text.Replace("<<nome>>", dati_alunni[1]).Replace("<<cognome>>", dati_alunni[2]);
                object start = 0, end = 0;

                pagina = liste_pagine[i];
                impostaRange(ref start, ref end, pagina);
                Range myRange = pagina.Range(ref start, ref end);
                
                myRange.Text = testo + "\n";
            }
        }

        public List<String> EstraggoAssenze(List<String> elenco, string matricola)
        {
            List<String> assenze = new List<string> ();

            foreach (string assenza in elenco)
            {
                string[] vet = assenza.Split(';');

                if (vet[0] == matricola)
                {
                    assenze.Add(vet[1] + ";" + vet[2]);
                }
            }

            return assenze;
        }

        public Table creaTabella(object start, object end, int r, int c, Document pagina)
        {
            Table myTable;
            Range myRange = pagina.Range(ref start, ref end);
            myTable = pagina.Tables.Add(myRange, r, c);
            myTable.Borders.Enable = 1;
            return myTable;
        }

        public void StampoTabella(List<string> assenze, List<string> alunni)
        {
            object start = 0;
            object end = 0;
            for (int i = 0; i < alunni.Count; i++)
            {
                List<String> elenco = EstraggoAssenze(assenze, alunni[i].Split(';')[0]);
                Document pagina = liste_pagine[i];
                impostaRange(ref start, ref end, pagina);

                if (elenco.Count > 0)
                {
                    Table tab = creaTabella(start, end, elenco.Count, elenco[0].Split(';').Length, pagina);
                    for (int j = 1; j <= elenco.Count; j++)
                    {
                        string[] dati = elenco[j - 1].Split(';');

                        for (int k = 1; k <= dati.Length; k++)
                        {
                            tab.Cell(j, k).Range.Text = dati[k - 1];
                        }
                    }

                } else
                {
                    
                    impostaRange(ref start, ref end, pagina);
                    Range myRange = pagina.Range(ref start, ref end);

                    myRange.Text = "L'alunno non ha fatto assenze" + "\n";
                }
            }
            

        }
    }

}
