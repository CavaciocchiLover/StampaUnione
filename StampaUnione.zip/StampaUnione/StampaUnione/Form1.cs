﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Office.Core;
using Microsoft.Office.Interop.Word;

namespace StampaUnione
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        List<String> alunni;
        List<String> assenze;

        clsWord word = new clsWord();
        
        private void Form1_Load(object sender, EventArgs e)
        {
            alunni = new List<String>();
            assenze = new List<String>();

            if(!File.Exists("Alunni.txt") || !File.Exists("Assenze.txt") || !File.Exists("base.txt"))
            {
                MessageBox.Show("Devi aggiungere i file");
                this.Close();
            } else
            {
                StreamReader sr = new StreamReader("Alunni.txt");

                sr.ReadLine();

                while (!sr.EndOfStream)
                {
                    string[] riga = sr.ReadLine().Split(';');
                    if (riga[0].Length == 4)
                    {
                        alunni.Add(riga[0] + ';' + riga[1] + ';' + riga[2]);
                    }
                }

                sr.Close();

                sr = new StreamReader("Assenze.txt");

                sr.ReadLine();
                
                while (!sr.EndOfStream)
                {
                    string[] riga = sr.ReadLine().Split(';');
                    if (riga[0].Length == 4 && riga[2].Length == 1)
                    {
                        try
                        {
                            Convert.ToDateTime(riga[1]);
                            assenze.Add(riga[0] + ';' + riga[1] + ';' + riga[2]);
                        }
                        catch
                        {
                        }
                        
                    }
                    
                }

                sr.Close();
            }
        }

        private void btnNuovoAlunno_Click(object sender, EventArgs e)
        {
        }

        private void btnStampoPDF_Click(object sender, EventArgs e)
        {

        }

        private void btnCreaDocumento_Click(object sender, EventArgs e)
        {
            word.creaDocumento(alunni.Count,true);

            StreamReader sr = new StreamReader("base.txt");

            string _base = sr.ReadToEnd();

            sr.Close();

            _base = _base.Replace("<<data>>", DateTime.Today.ToShortDateString());
            _base = _base.Replace("<<tabella>>", "|");

            string[] arr = _base.Split('|');

            word.inserisciTesto(arr[0], alunni);
            word.StampoTabella(assenze, alunni);
            word.inserisciTesto(arr[1], alunni);
        }
    }
}
