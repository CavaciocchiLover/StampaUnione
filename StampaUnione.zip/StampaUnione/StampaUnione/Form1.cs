﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Office.Core;
using Microsoft.Office.Interop.Word;

namespace StampaUnione
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        List<String> alunni;
        List<String> assenze;

        clsWord word = new clsWord();

        private void Form1_Load(object sender, EventArgs e)
        {
            alunni = new List<String>();
            assenze = new List<String>();

            if (!File.Exists("Alunni.txt") || !File.Exists("Assenze.txt") || !File.Exists("base.txt"))
            {
                MessageBox.Show("Devi aggiungere i file");
                this.Close();
            }
            else
            {
                StreamReader sr = new StreamReader("Alunni.txt");

                sr.ReadLine();

                while (!sr.EndOfStream)
                {
                    string[] riga = sr.ReadLine().Split(';');
                    if (riga[0].Length == 4)
                    {
                        alunni.Add(riga[0] + ';' + riga[1] + ';' + riga[2]);
                    }
                }

                sr.Close();

                sr = new StreamReader("Assenze.txt");

                sr.ReadLine();

                while (!sr.EndOfStream)
                {
                    string[] riga = sr.ReadLine().Split(';');
                    if (riga[0].Length == 4 && riga[2].Length == 1)
                    {
                        try
                        {
                            Convert.ToDateTime(riga[1]);
                            assenze.Add(riga[0] + ';' + riga[1] + ';' + riga[2]);
                        }
                        catch
                        {
                        }

                    }

                }

                sr.Close();
            }
        }

        private void btnNuovoAlunno_Click(object sender, EventArgs e)
        {
            if (controllo_matricola(txtMatricolaAlunno.Text.Trim().ToLower()) && controllo_nome(txtNome.Text.Trim().ToLower()) &&
                controllo_nome(txtCognome.Text.Trim().ToLower()))
            {
                string matricola = txtMatricolaAlunno.Text.Trim().ToLower();

                bool esiste = false;
                int i = 0;

                while (!esiste && i < alunni.Count)
                {
                    if (alunni[i].Split(';')[0] == matricola)
                    {
                        esiste = true;
                    }
                    else
                    {
                        i++;
                    }
                }

                if (!esiste)
                {
                    alunni.Add(matricola + ";" + txtNome.Text.Trim().ToLower() + ";" +
                    txtCognome.Text.Trim().ToLower());

                    StreamWriter sw = new StreamWriter("Alunni.txt", true);

                    sw.WriteLine(matricola + ";" + txtNome.Text.Trim().ToLower() + ";" +
                    txtCognome.Text.Trim().ToLower());

                    sw.Close();
                }
                else
                {
                    MessageBox.Show("L'alunno già esiste");
                }


            }
        }

        private void btnStampoPDF_Click(object sender, EventArgs e)
        {
            DialogResult ris = fbd.ShowDialog();

            if (ris == DialogResult.OK && !string.IsNullOrWhiteSpace(fbd.SelectedPath))
            {
                word.SalvoPDF(fbd.SelectedPath, alunni);
            }

        }

        private void btnCreaDocumento_Click(object sender, EventArgs e)
        {
            word.creaDocumento(alunni.Count, true);

            StreamReader sr = new StreamReader("base.txt");

            string _base = sr.ReadToEnd();

            sr.Close();

            _base = _base.Replace("<<data>>", DateTime.Today.ToShortDateString());
            _base = _base.Replace("<<tabella>>", "|");

            string[] arr = _base.Split('|');

            word.inserisciTesto(arr[0], alunni);
            word.StampoTabella(assenze, alunni);
            word.inserisciTesto(arr[1], alunni);
        }

        private void btnChiudiDocumento_Click(object sender, EventArgs e)
        {
            word.Chiudi();
        }

        private void btnNuovaAssenza_Click(object sender, EventArgs e)
        {
            if (controllo_matricola(txtMatricolaAssenza.Text.Trim().ToLower()) && controllo_data(txtData.Text.Trim().ToLower()) &&
                controllo_assenza(txtAssenza.Text.Trim().ToUpper()))
            {
                string matricola = txtMatricolaAssenza.Text.Trim().ToLower();

                bool esiste = false;
                int i = 0;

                while (!esiste && i < alunni.Count)
                {
                    if (alunni[i].Split(';')[0] == matricola)
                    {
                        esiste = true;
                    }
                    else
                    {
                        i++;
                    }
                }

                if (esiste)
                {
                    string data = txtData.Text.Trim().ToLower();
                    i = 0;
                    esiste = false;

                    while (!esiste && i < assenze.Count)
                    {
                        if (assenze[i].Split(';')[1] == data)
                        {
                            esiste = true;
                        }
                        else
                        {
                            i++;
                        }
                    }

                    if (!esiste)
                    {
                        assenze.Add(matricola + ";" + data + ";" +
                    txtAssenza.Text.Trim().ToUpper());

                        StreamWriter sw = new StreamWriter("Assenze.txt", true);

                        sw.WriteLine(matricola + ";" + data + ";" +
                        txtAssenza.Text.Trim().ToUpper());

                        sw.Close();
                    }
                    else
                    {
                        MessageBox.Show("Già esiste un'assenza in questa data per questo alunno");
                    }
                }


                else
                {
                    MessageBox.Show("L'alunno non esiste");
                }
            }
        }

        private bool controllo_assenza(string testo)
        {
            if (testo == "R" || testo == "A" || testo == "U")
            {
                return true;
            }
            else
            {
                MessageBox.Show("Tipo di assenza non valida");
                return false;
            }
        }

        private bool controllo_data(string testo)
        {
            bool validita = false;
            try
            {
                if (Convert.ToDateTime(testo) < DateTime.Now &&
                    Convert.ToDateTime(testo).Year > 2020)
                {
                    validita = true;
                }
                else
                {
                    MessageBox.Show("Data non valida");
                }
            }
            catch
            {
                MessageBox.Show("Data non valida");
            };

            return validita;
        }

        private bool controllo_nome(string testo)
        {
            if (Regex.IsMatch(testo, @"^[A-Za-zà-ù]{2,}$"))
            {
                return true;
            }
            else
            {
                MessageBox.Show("Il nome e/o il cognome non è valido");
                return false;
            }
        }

        private bool controllo_matricola(string testo)
        {
            if (Regex.IsMatch(testo, @"^m\d{3}$"))
            {
                return true;
            }
            else
            {
                MessageBox.Show("La matricola non è valida");
                return false;
            }
        }
    }
}
