$(document).ready(function () {
    LeggoFile('prova.json')
        .then(dati => {
            localStorage.setItem("auto", dati);
        })
        .catch(error => console.error('Errore rilevato:', error));

    $("#carica").on("click", GeneroTabella);
    $("#resetta").on("click", Resetto);

    $("<div id='wrapper' class='p-3 mb-5 bg-body-rounded'></div>").appendTo("body")
    $("<table class='table table-hover table-striped'></table>").appendTo("#wrapper");
    $("<form></form>").appendTo("#wrapper");
});

function LeggoFile(url) {
    return new Promise((resolve, reject) => {
        $.ajax({
            url: url, async: true, success: (response) => {
                resolve(JSON.stringify(response));
            }, error: (error) => {
                reject(error);
            }
        });
    });
}

function GeneroTabella() {
    let json = JSON.parse(localStorage.getItem("auto"));
    let tabella = $(".table")

    CaricoIntestazione(json, tabella);
    CaricoDati(json, tabella);

    Ricerca("CD650MB")
        .then((risposta) => {
            console.log(risposta)
        })
        .catch((err) => {
            alert(err);
        })
}

function CaricoIntestazione(json, tabella){
    let thead = $("<thead></thead>").appendTo(tabella);

    let tr = $("<tr></tr>").appendTo(thead);

    for (const valore of Object.keys(json[0])) {
        $("<th scope='col'></th>")
            .text(valore)
            .appendTo(tr)
    }
}

function CaricoDati(json, tabella) {
    let tbody = $("<tbody></tbody>")
        .appendTo(tabella);

    $.each(json, (_, item) => {
        let tr = $("<tr></tr>").appendTo(tbody);

        $.each(item, (_, valore) => {
            $("<td></td>")
                .text(valore)
                .appendTo(tr);
        })
    })
}

function Resetto() {
    let tabella = $(".table");

    if (tabella.html() !== ""){
        tabella.html("");
    } else {
        alert("Tabella vuota");
    }
}

function Ricerca(targa) {
    return new Promise((resolve, reject) => {
        let json = JSON.parse(localStorage.getItem("auto"));

        $.each(json, (_, item) => {
            $.each(item, (_, valore) => {
                if(valore === targa){
                    resolve(item);
                }
            })
        })

        reject("Targa non trovata");
    })
}